package com.example.appchat.client.controller;

import com.example.appchat.client.model.Message;
import com.example.appchat.client.service.ChatService;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ResourceBundle;

public class ChatController implements Initializable {
    @FXML
    private Label lbUsername;
    @FXML
    private TextArea txtBoxMessage;
    @FXML
    private TextField txtInput;

    private static String username;
    private DatagramSocket socket;
    private final ChatService chatService;

    public static void setLbUsername(String name) {
        username = name;
    }

    public ChatController() {
        chatService = new ChatService();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) { // khoi tao nhung thu can thiet khi open cua so
        lbUsername.setText(username);
        try {
            initMessageHistory();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        try {
            // Khởi tạo DatagramSocket cho client
            socket = new DatagramSocket();

            // Mở một luồng để lắng nghe dữ liệu từ server
            new Thread(() -> {
                try {
                    byte[] receiveData = new byte[1024];
                    while (true) {
                        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                        socket.receive(receivePacket);

                        // Lấy dữ liệu từ DatagramPacket
                        String receivedMessage = new String(receivePacket.getData(), 0, receivePacket.getLength(), StandardCharsets.UTF_8);
                        System.out.println("client:" + receivedMessage);
                        txtBoxMessage.appendText(receivedMessage + "\n");

                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void onClickSend(ActionEvent actionEvent) {
        String messageInput = txtInput.getText();

        String message = String.format("%s: %s", username, messageInput);
        if (!message.isEmpty()) {
            try {
                // Gửi dữ liệu tới server
                byte[] sendData = message.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, InetAddress.getByName("localhost"), 8080);
                socket.send(sendPacket);

                // Xóa nội dung trong TextField sau khi gửi
                txtInput.clear();

                // Luu lai message
                Message saveMessage = new Message();
                saveMessage.setMessage(messageInput);
                saveMessage.setTimestamp(LocalDateTime.now());
                chatService.saveChatHistory(saveMessage, username);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }



    private void initMessageHistory() throws SQLException { // lay lich su message va hien thi len
        List<String> messageList = chatService.getHistoryMessage();

        messageList.forEach(message -> txtBoxMessage.appendText(message + "\n"));

    }
}
