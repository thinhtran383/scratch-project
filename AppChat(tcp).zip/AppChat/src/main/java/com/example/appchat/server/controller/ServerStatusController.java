package com.example.appchat.server.controller;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class ServerStatusController {
    @FXML
    private Label lbStatus;
    @FXML
    private Label lbNumberConnection;
    private boolean isServerRunning;
    private DatagramSocket serverSocket;

    private static final int PORT = 8080;
    private static final int BUFFER_SIZE = 1024;
    private static final ArrayList<InetAddress> clientAddresses = new ArrayList<>();
    private static final ArrayList<Integer> clientPorts = new ArrayList<>();

    public ServerStatusController() {
        isServerRunning = false;
    }

    public void onClickStartServer(ActionEvent actionEvent) {  // phuong thuc dieu khien nut start
        lbStatus.setText("Server đang chạy...");
        if (!isServerRunning) {
            System.out.println("Server listening...");
            try {
                serverSocket = new DatagramSocket(PORT);
                isServerRunning = true;

                // Mở luồng để chấp nhận các kết nối từ client
                new Thread(() -> {
                    while (isServerRunning) {
                        try {
                            byte[] receiveData = new byte[BUFFER_SIZE];
                            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                            serverSocket.receive(receivePacket);

                            InetAddress clientAddress = receivePacket.getAddress();
                            int clientPort = receivePacket.getPort();

                            // Thêm địa chỉ client vào danh sách nếu chưa tồn tại
                            if (!clientAddresses.contains(clientAddress) || !clientPorts.contains(clientPort)) {
                                clientAddresses.add(clientAddress);
                                clientPorts.add(clientPort);
                            }

                            // Lấy dữ liệu từ DatagramPacket
                            String receivedMessage = new String(receivePacket.getData(), 0, receivePacket.getLength(), StandardCharsets.UTF_8);
                            System.out.println("Received from client: " + receivedMessage);

                            // Gửi dữ liệu trả về client
                            sendDataToAllClients(receivedMessage);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void sendDataToAllClients(String message) {
        byte[] sendData = message.getBytes(StandardCharsets.UTF_8);
        int numberOfConnections = clientAddresses.size(); // Số lượng kết nối đến server
        Platform.runLater(() -> {
            lbNumberConnection.setText(Integer.toString(numberOfConnections)); // Cập nhật số lượng kết nối lên lbNumberConnection
        });
        for (int i = 0; i < clientAddresses.size(); i++) {
            InetAddress clientAddress = clientAddresses.get(i);
            int clientPort = clientPorts.get(i);
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
            try {
                serverSocket.send(sendPacket);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void onClickStopServer(ActionEvent actionEvent) { // phuong thuc dieu khien nut stop
        if (isServerRunning) {
            serverSocket.close();
            isServerRunning = false;
            System.out.println("Server stopped.");
            lbStatus.setText("Server đã dừng!");
            lbNumberConnection.setText("0");
        }
    }
}
